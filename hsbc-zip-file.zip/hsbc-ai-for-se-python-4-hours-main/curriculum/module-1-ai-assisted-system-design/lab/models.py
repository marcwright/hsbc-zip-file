from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, field_validator


class PaymentState(str, Enum):
    SUBMITTED = "submitted"
    SETTLED = "settled"
    FAILED = "failed"


class PaymentEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_id: str
    payment_id: str
    state: PaymentState
    occurred_at: datetime

    @field_validator("event_id", "payment_id")
    @classmethod
    def validate_id(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("id must be non-empty")
        if len(value) > 64:
            raise ValueError("id must be at most 64 characters")
        return value

    @field_validator("occurred_at")
    @classmethod
    def validate_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("occurred_at must be timezone-aware")
        return value


class PaymentStatus(BaseModel):
    model_config = ConfigDict(extra="forbid")

    payment_id: str
    state: PaymentState
    updated_at: datetime

    @field_validator("payment_id")
    @classmethod
    def validate_id(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("payment_id must be non-empty")
        return value

    @field_validator("updated_at")
    @classmethod
    def validate_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("updated_at must be timezone-aware")
        return value


class ErrorResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: str | None = None
    message: str | None = None
